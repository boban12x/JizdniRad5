# Jízdní řád 5 – prototyp Android aplikace

První zdrojový projekt pro Android Studio. Aplikace přijme výchozí místo, cíl a čas odjezdu, vzorkuje trasu přibližně po pěti minutách a ponechá změny pojmenovaných míst, takže výsledný seznam není pevně vázán na pětiminutové intervaly. Na rozpoznaných českých dálnicích (např. D1, D5) aplikuje konzervativní plánovací rychlost nejvýše 90 km/h.

## Otevření projektu
1. Rozbal ZIP.
2. V Android Studio zvol **Open** a vyber složku `JizdniRad5`.
3. Nech Gradle dokončit synchronizaci.
4. Připoj telefon s povoleným USB debuggingem nebo spusť emulátor.
5. Zvol **Build > Build APK(s)**. Výstup bývá v `app/build/outputs/apk/debug/app-debug.apk`.

## Použité služby
- OSRM demo server: výpočet automobilové trasy.
- OpenStreetMap Nominatim: vyhledání a pojmenování míst.

Tento prototyp je určen k osobnímu testování. Veřejné demo služby mají limity, mohou být nedostupné a nejsou vhodné jako garantované produkční backendy. Před pravidelným používáním je vhodné zvolit vlastní/komerční routing službu, dodržet její podmínky a doplnit lepší ošetření chyb.

## Omezení první verze
- Časy jsou odhady podle routovací služby, nikoliv živá predikce provozu.
- Vyhledávání názvů míst závisí na kvalitě mapových dat.
- Vzorkování po pěti minutách je orientační; při velmi krátké trase může být méně bodů.
- Neobsahuje zatím mapové zobrazení, export ani ukládání tras.


## Další omezení
- Záchytná místa se určují reverzním geokódováním přibližných bodů trasy; ne každé místo bude vhodná zastávka.
- Limit 90 km/h se v prototypu použije heuristicky pouze tehdy, když mapová služba vrátí rozpoznatelný český dálniční ref/název. Nejde o garantované rozpoznání všech dálnic.
- Veřejný OSRM demo server poskytuje výchozí odhad trasy; skutečná doprava, nehody a zdržení nejsou zahrnuty.
