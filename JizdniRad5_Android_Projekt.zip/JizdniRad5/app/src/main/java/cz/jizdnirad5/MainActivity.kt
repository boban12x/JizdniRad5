package cz.jizdnirad5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

private data class Place(val name: String, val lat: Double, val lon: Double)
private data class Stop(val time: String, val place: String, val km: Double, val lat: Double, val lon: Double)
private data class RoutePoint(val lat: Double, val lon: Double, val cumulativeMeters: Double, val cumulativeSeconds: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AppScreen() } }
    }
}

@Composable
private fun AppScreen() {
    var start by remember { mutableStateOf("Praha, Česká republika") }
    var end by remember { mutableStateOf("Brno, Česká republika") }
    var departure by remember { mutableStateOf("08:00") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Zadej začátek a cíl trasy.") }
    var stops by remember { mutableStateOf(listOf<Stop>()) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Text("Jízdní řád 5", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Automobilová trasa s průjezdními body po 5 minutách.")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = start, onValueChange = { start = it }, label = { Text("Začátek trasy") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = end, onValueChange = { end = it }, label = { Text("Konec trasy") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = departure, onValueChange = { departure = it }, label = { Text("Čas odjezdu (HH:mm)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    error = null
                    stops = emptyList()
                    busy = true
                    status = "Vyhledávám místa a počítám trasu…"
                    scope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) {
                                buildTimetable(start.trim(), end.trim(), departure.trim())
                            }
                            stops = result
                            status = "Hotovo: ${result.size} průjezdních bodů."
                        } catch (e: Exception) {
                            error = e.message ?: "Nepodařilo se vypočítat trasu."
                            status = "Výpočet se nezdařil."
                        } finally {
                            busy = false
                        }
                    }
                },
                enabled = !busy && start.isNotBlank() && end.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Počítám…" else "Vytvořit jízdní řád") }
            Spacer(Modifier.height(10.dp))
            Text(status, style = MaterialTheme.typography.bodyMedium)
            error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            if (stops.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Průjezdní body", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Body se vybírají podle pojmenovaných míst na trase. Na rozpoznaných českých dálnicích se plánuje nejvýše 90 km/h. Živý provoz není zahrnut.")
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(stops) { stop ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${stop.time}  •  ${"%.1f".format(Locale.getDefault(), stop.km)} km", fontWeight = FontWeight.Bold)
                                Text(stop.place)
                                Text("GPS: %.5f, %.5f".format(Locale.US, stop.lat, stop.lon), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Data trasy: OSRM demo server a OpenStreetMap Nominatim. Pro osobní testování; dostupnost veřejných služeb není garantována.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun buildTimetable(startText: String, endText: String, departure: String): List<Stop> {
    val timeParts = departure.split(":")
    require(timeParts.size == 2) { "Čas zadej ve formátu HH:mm, například 08:00." }
    val hourValue = timeParts[0].toIntOrNull()
    val minuteValue = timeParts[1].toIntOrNull()
    require(hourValue != null && minuteValue != null && hourValue in 0..23 && minuteValue in 0..59) {
        "Neplatný čas. Použij formát HH:mm."
    }
    val hour = hourValue!!
    val minute = minuteValue!!

    val start = geocode(startText) ?: error("Začátek trasy nebyl nalezen. Zkus doplnit město nebo stát.")
    val end = geocode(endText) ?: error("Cíl trasy nebyl nalezen. Zkus doplnit město nebo stát.")

    val routeUrl = "https://router.project-osrm.org/route/v1/driving/" +
        "${start.lon},${start.lat};${end.lon},${end.lat}?overview=full&steps=true&geometries=geojson"
    val routeRoot = getObject(routeUrl)
    require(routeRoot.optString("code") == "Ok") { "Mapová služba nedokázala najít sjízdnou trasu." }
    val route = routeRoot.getJSONArray("routes").getJSONObject(0)
    val steps = route.getJSONArray("legs").getJSONObject(0).getJSONArray("steps")

    // Build a route timeline. On Czech motorway refs (D1, D5, ...) use a conservative
    // planning speed cap of 90 km/h by extending the step duration when necessary.
    val points = mutableListOf<RoutePoint>()
    var cumulativeMeters = 0.0
    var cumulativeSeconds = 0.0

    for (i in 0 until steps.length()) {
        val step = steps.getJSONObject(i)
        val rawDuration = step.optDouble("duration", 0.0)
        val stepDistance = step.optDouble("distance", 0.0)
        val name = step.optString("name", "")
        val ref = step.optString("ref", "")
        val looksLikeCzechMotorway =
            Regex("""\bD\s?\d{1,2}\b""", RegexOption.IGNORE_CASE).containsMatchIn(ref) ||
            Regex("""\bD\s?\d{1,2}\b""", RegexOption.IGNORE_CASE).containsMatchIn(name) ||
            name.contains("dálnice", ignoreCase = true)

        val plannedDuration = if (looksLikeCzechMotorway) {
            max(rawDuration, stepDistance / (90.0 / 3.6))
        } else rawDuration

        val geometry = step.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
        val coords = mutableListOf<Pair<Double, Double>>()
        for (j in 0 until geometry.length()) {
            val coord = geometry.getJSONArray(j)
            coords.add(Pair(coord.getDouble(0), coord.getDouble(1))) // lon, lat
        }
        if (coords.isEmpty()) continue

        val segmentLengths = mutableListOf<Double>()
        var geometryMeters = 0.0
        for (j in 1 until coords.size) {
            val a = coords[j - 1]
            val b = coords[j]
            val d = distanceMeters(a.second, a.first, b.second, b.first)
            segmentLengths.add(d)
            geometryMeters += d
        }

        var localMeters = 0.0
        points.add(RoutePoint(coords.first().second, coords.first().first, cumulativeMeters, cumulativeSeconds))
        for (j in 1 until coords.size) {
            localMeters += segmentLengths[j - 1]
            val ratio = if (geometryMeters > 0.0) localMeters / geometryMeters else j.toDouble() / max(1, coords.size - 1)
            points.add(
                RoutePoint(
                    coords[j].second, coords[j].first,
                    cumulativeMeters + stepDistance * ratio,
                    cumulativeSeconds + plannedDuration * ratio
                )
            )
        }
        cumulativeMeters += stepDistance
        cumulativeSeconds += plannedDuration
    }

    if (points.isEmpty()) error("Trasa neobsahuje geometrii.")

    // Sample approximately every five minutes, then keep only meaningful named-place
    // changes. The displayed stops therefore follow real map locations, not fixed time slots.
    val output = mutableListOf<Stop>()
    val totalSeconds = cumulativeSeconds
    val sampleCount = max(1, ceil(totalSeconds / 300.0).toInt())
    var previousPlaceKey = ""
    for (n in 0..sampleCount) {
        val targetSeconds = min(n * 300.0, totalSeconds)
        val point = points.minByOrNull { abs(it.cumulativeSeconds - targetSeconds) } ?: points.last()
        val placeName = if (n == 0) start.name else if (n == sampleCount) end.name
            else reverseGeocode(point.lat, point.lon) ?: "Pojmenované místo na trase"
        val placeKey = placeName.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]"), "")
        val isEndpoint = n == 0 || n == sampleCount
        if (isEndpoint || placeKey != previousPlaceKey) {
            val totalClockMinutes = hour * 60 + minute + (point.cumulativeSeconds / 60.0).roundToInt()
            val time = "%02d:%02d".format((totalClockMinutes / 60) % 24, totalClockMinutes % 60)
            output.add(
                Stop(
                    time, placeName, point.cumulativeMeters / 1000.0,
                    point.lat, point.lon
                )
            )
            previousPlaceKey = placeKey
        }
    }
    return output.distinctBy { "${it.time}:${"%.4f".format(Locale.US, it.lat)}:${"%.4f".format(Locale.US, it.lon)}" }
}

private fun geocode(query: String): Place? {
    val encoded = URLEncoder.encode(query, "UTF-8")
    val root = getArray("https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1")
    if (root.length() == 0) return null
    val item = root.getJSONObject(0)
    val address = item.optString("display_name", query).split(",").take(3).joinToString(",")
    return Place(address, item.getString("lat").toDouble(), item.getString("lon").toDouble())
}

private fun reverseGeocode(lat: Double, lon: Double): String? {
    return try {
        val root = getObject("https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=jsonv2&zoom=10")
        val address = root.optJSONObject("address") ?: return root.optString("name").takeIf { it.isNotBlank() }
        val road = address.optString("road")
        val village = listOf("village", "town", "city", "municipality", "hamlet", "suburb")
            .firstNotNullOfOrNull { key -> address.optString(key).takeIf { it.isNotBlank() } }
        listOfNotNull(village, road.takeIf { it.isNotBlank() }).distinct().joinToString(", ").ifBlank {
            root.optString("name").takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) { null }
}


private fun getArray(url: String): org.json.JSONArray {
    Thread.sleep(1100)
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15000
    conn.readTimeout = 20000
    conn.setRequestProperty("User-Agent", "JizdniRad5/1.0 (personal Android prototype)")
    conn.setRequestProperty("Accept-Language", "cs")
    try {
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        return org.json.JSONArray(text)
    } finally { conn.disconnect() }
}

private fun getObject(url: String): JSONObject {
    Thread.sleep(1100)
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15000
    conn.readTimeout = 20000
    conn.setRequestProperty("User-Agent", "JizdniRad5/1.0 (personal Android prototype)")
    conn.setRequestProperty("Accept-Language", "cs")
    try {
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        return JSONObject(text)
    } finally { conn.disconnect() }
}

private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(sqrt(a.coerceIn(0.0, 1.0)))
}
